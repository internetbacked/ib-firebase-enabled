=== Ib Firebase Enabled ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://paypal.me/ihsanberahim
Tags: wordpress, firebase
Requires at least: 4.5
Tested up to: 4.9.8
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Enable Firebase features in Wordpress

== Description ==

Enable Firebase features in Wordpress

Currently integrated:

*   Facebook Auth

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `ib-firebase-enabled/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 0.1 =

* Initial release